package com.ithobbies.haseeb.jitsi_meet_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
